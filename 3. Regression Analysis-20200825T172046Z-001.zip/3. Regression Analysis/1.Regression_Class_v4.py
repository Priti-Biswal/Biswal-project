import pandas as pd
import numpy as np
import matplotlib as matlab
import statsmodels

###############LAB:Correlation Calculation########################

#Dataset: Air Travel Data\Air_travel.csv
#Importing Air passengers data
air = pd.read_csv("D:\\Google Drive\\Training\\Datasets\\AirPassengers\\AirPassengers.csv")
air.shape
air.columns.values
air.head(10)
air.describe()

#Find the correlation between number of passengers and promotional budget.
np.corrcoef(air.Passengers,air.Promotion_Budget)

#Draw a scatter plot between number of passengers and promotional budget
#matlab.pyplot.scatter(air.Passengers, air.Promotion_Budget)

#Find the correlation between number of passengers and Service_Quality_Score
np.corrcoef(air.Passengers,air.Service_Quality_Score)


##############################################Regression######################################

#Correlation between promotion and passengers count
np.corrcoef(air.Passengers,air.Promotion_Budget)

#Draw a scatter plot between   Promotion_Budget and Passengers. Is there any any pattern between Promotion_Budget and Passengers?
matlab.pyplot.scatter(air.Promotion_Budget,air.Passengers)

#Build a linear regression model and estimate the expected passengers for a Promotion_Budget is 650,000
##Regression Model  promotion and passengers count

# Promo budget
# Passengers

import statsmodels.formula.api as sm
model = sm.ols(formula='Passengers ~ Promotion_Budget', data=air)
fitted1 = model.fit()
fitted1.summary()

#b0 ==> Intercept  ==> 1259.6058
#b1 ===> coeff prmo budget ==>0.0695 

# y = b0 +b1*x 
# Passengers = 1259.6058 + 0.0695 * (promo_budget)
# promo_budget = 500,000 ==? Predict passengers ? 

1259.6058 + 0.0695 * (500000)
# promo_budget = 650,000 ==? Predict passengers ? 
1259.6058 + 0.0695 * (650000)

##Regression Model inter_metro_flight_ratio and passengers count
#matlab.pyplot.scatter(air.Inter_metro_flight_ratio,air.Passengers)

import statsmodels.formula.api as sm
model = sm.ols(formula='Passengers ~ Inter_metro_flight_ratio', data=air)
fitted2 = model.fit()
fitted2.summary()


#############################################################################
############ Lab:R Sqaure ##################
#What is the R-square value of Passengers vs Promotion_Budget model?
fitted1.summary()

#What is the R-square value of Passengers vs Inter_metro_flight_ratio

fitted2.summary()


################################################
#############Lab: Multiple Regerssion Model ####################
#Build a multiple regression model to predict the number of passengers

import statsmodels.formula.api as sm
model = sm.ols(formula='Passengers ~ Promotion_Budget+Service_Quality_Score+Inter_metro_flight_ratio', data=air)
fitted = model.fit()
fitted.summary()

#What is R-square value
fitted.summary()

#Are there any predictor variables that are not impacting the dependent variable 
##Inter_metro_flight_ratio is dropped
import statsmodels.formula.api as sm
model = sm.ols(formula='Passengers ~ Promotion_Budget+Service_Quality_Score', data=air)
fitted = model.fit()
fitted.summary()
 
import statsmodels.formula.api as sm
model = sm.ols(formula='Passengers ~ Service_Quality_Score', data=air)
fitted = model.fit()
fitted.summary()

###############################################
##Adjusted R-Square

adj_sample=pd.read_csv("D:\\Google Drive\\Training\\Datasets\\Adjusted RSquare\\Adj_Sample.csv")
#Build a model to predict y using x1,x2 and x3. Note down R-Square and Adj R-Square values 
model = sm.ols(formula='Y ~ x1+x2+x3', data=adj_sample)
fitted = model.fit()
fitted.summary()
#R-Squared 

#Model2
model = sm.ols(formula='Y ~ x1+x2+x3+x4+x5+x6', data=adj_sample)
fitted = model.fit()
fitted.summary()

#Model3
model = sm.ols(formula='Y ~ x1+x2+x3+x4+x5+x6+x7+x8', data=adj_sample)
fitted = model.fit()
fitted.summary()

#################################################################################3
#####Multiple Regression- issues
    
#Import Final Exam Score data
final_exam=pd.read_csv("D:\\Google Drive\\Training\\Datasets\\Final Exam\\Final Exam Score.csv")

#Size of the data
final_exam.shape

#Variable names
final_exam.columns

#First few observations
final_exam.head(10)

#Build a model to predict final score using the rest of the variables.

import statsmodels.formula.api as sm
model1 = sm.ols(formula='Final_exam_marks ~ Sem1_Science+Sem2_Science+Sem1_Math+Sem2_Math', data=final_exam)
fitted1 = model1.fit()
fitted1.summary()
fitted1.rsquared


#How are Sem2_Math & Final score related? As Sem2_Math score increases, what happens to Final score? 

#Remove "Sem1_Math" variable from the model and rebuild the model
import statsmodels.formula.api as sm
model2 = sm.ols(formula='Final_exam_marks ~ Sem1_Science+Sem2_Science+Sem2_Math', data=final_exam)
fitted2 = model2.fit()
fitted2.summary()


#Is there any change in R square or Adj R square

#How are Sem2_Math  & Final score related now? As Sem2_Math score increases, what happens to Final score? 

#Scatter Plot between the predictor variables
matlab.pyplot.scatter(final_exam.Sem1_Math,final_exam.Sem2_Math)

#Find the correlation between Sem1_Math & Sem2_Math 
np.correlate(final_exam.Sem1_Math,final_exam.Sem2_Math)

########################Multicollinearity detection#########################
##Testing Multicollinearity

model1 = sm.ols(formula='Final_exam_marks ~ Sem1_Science+Sem2_Science+Sem1_Math+Sem2_Math', data=final_exam)
fitted1 = model1.fit()
fitted1.summary()
fitted1.summary2()

#Code for VIF Calculation

#Writing a function to calculate the VIF values

def vif_cal(input_data, dependent_col):
    x_vars=input_data.drop([dependent_col], axis=1)
    xvar_names=x_vars.columns
    for i in range(0,xvar_names.shape[0]):
        y=x_vars[xvar_names[i]] 
        x=x_vars[xvar_names.drop(xvar_names[i])]
        rsq=sm.ols(formula="y~x", data=x_vars).fit().rsquared  
        vif=round(1/(1-rsq),2)
        print (xvar_names[i], " VIF = " , vif)

#Calculating VIF values using that function
vif_cal(input_data=final_exam, dependent_col="Final_exam_marks")

#VIF Values given by statsmodels.stats.outliers_influence.variance_inflation_factor are not accurate
#import statsmodels.stats.outliers_influence
#help(statsmodels.stats.outliers_influence.variance_inflation_factor)
#statsmodels.stats.outliers_influence.variance_inflation_factor(final_exam.drop(["Final_exam_marks"], axis=1).as_matrix(), 0)
#statsmodels.stats.outliers_influence.variance_inflation_factor(final_exam.drop(["Final_exam_marks"], axis=1).as_matrix(), 1)
#statsmodels.stats.outliers_influence.variance_inflation_factor(final_exam.drop(["Final_exam_marks"], axis=1).as_matrix(), 2)
#statsmodels.stats.outliers_influence.variance_inflation_factor(final_exam.drop(["Final_exam_marks"], axis=1).as_matrix(), 3)


import statsmodels.formula.api as sm
model2 = sm.ols(formula='Final_exam_marks ~ Sem1_Science+Sem2_Science+Sem2_Math', data=final_exam)
fitted2 = model2.fit()
fitted2.summary()

vif_cal(input_data=final_exam.drop(["Sem1_Math"], axis=1), dependent_col="Final_exam_marks")


vif_cal(input_data=final_exam.drop(["Sem1_Math","Sem1_Science"], axis=1), dependent_col="Final_exam_marks")

## VIF


###############################################
##Multiple Regression model building 

Webpage_Product_Sales=pd.read_csv("D:\\Google Drive\\Training\\Datasets\\Webpage_Product_Sales\\Webpage_Product_Sales.csv")
Webpage_Product_Sales.shape
Webpage_Product_Sales.columns


import statsmodels.formula.api as sm
model1 = sm.ols(formula='Sales ~ Web_UI_Score+Server_Down_time_Sec+Holiday+Special_Discount+Clicks_From_Serach_Engine+Online_Ad_Paid_ref_links+Social_Network_Ref_links+Month+Weekday+DayofMonth', data=Webpage_Product_Sales)
fitted1 = model1.fit()
fitted1.summary()

#VIF
vif_cal(Webpage_Product_Sales,"Sales")

#
#Web_UI_Score+Server_Down_time_Sec+Holiday+Special_Discount+Clicks_From_Serach_Engine+Online_Ad_Paid_ref_links+Social_Network_Ref_links+Month+Weekday+DayofMonth



##Dropped Clicks_From_Serach_Engine based on VIF
import statsmodels.formula.api as sm
model2 = sm.ols(formula='Sales ~ Web_UI_Score+Server_Down_time_Sec+Holiday+Special_Discount+Online_Ad_Paid_ref_links+Social_Network_Ref_links+Month+Weekday+DayofMonth', data=Webpage_Product_Sales)
fitted2 = model2.fit()
fitted2.summary()

#VIF for the updated model
vif_cal(Webpage_Product_Sales.drop(["Clicks_From_Serach_Engine"],axis=1),"Sales")
#No VIF is more than 5


##Drop the less impacting variables based on p-values.
##Dropped Web_UI_Score based on P-value

import statsmodels.formula.api as sm
model3 = sm.ols(formula='Sales ~ Server_Down_time_Sec+Holiday+Special_Discount+Online_Ad_Paid_ref_links+Social_Network_Ref_links+Month+Weekday+DayofMonth', data=Webpage_Product_Sales)
fitted3 = model3.fit()
fitted3.summary()


#How many variables are there in the final model?
#10
#What is the R-squared of the final model?





























